package com.example.android.dodjinateren;

import java.sql.Date;
import java.sql.Time;
/**
 * Created by jane on 12/13/2017.
 */

public class Objava {

    private String teren;
    private String korisnik;
    private String sport;
    private Integer red;
    private int sat;
    private int minut;
    private String status;
    Objava()
    {

    }
    Objava(String t,String k,String sp,Integer red,int s,int m,String stat)
    {
        this.teren=t;
        this.korisnik=k;
        this.sport=sp;
        this.red=red;
        this.sat=s;
        this.minut=m;
        this.status=stat;
    }
    public String getTeren()
    {
        return  teren;
    }
    public String getKorisnik()
    {
        return korisnik;
    }
    public Integer getRed()
    {
        return  red;
    }
    public int getSat()
    {
        return sat;
    }
    public int getMinut()
    {
        return minut;
    }
    public String getSport()
    {
        return sport;
    }
    public String getStatus()
    {
        return status;
    }
}
