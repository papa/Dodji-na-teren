package com.example.android.dodjinateren;
import java.util.Calendar;
import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.sql.Time;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,GoogleMap.OnMapLongClickListener,GoogleMap.OnMarkerClickListener {

    static GoogleMap mMap;
    LocationManager locationManager;
    LocationListener locationListener;
    DatabaseReference mojabaza;
    static String prenos;
    Marker marker;
    LatLng userLocation;
    DatabaseReference mojabaza2;
    DatabaseReference mojabaza3;
    FirebaseUser user;
    Korisnik k;
    String s123;
    String t;
    String imek;
    private FirebaseAuth firebaseAuth;
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    {

                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);

                    }

                }

            }

        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        mojabaza = FirebaseDatabase.getInstance().getReference("tereni");
        mojabaza2=FirebaseDatabase.getInstance().getReference("Korisnici");
        mojabaza3=FirebaseDatabase.getInstance().getReference("Objave");
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        mMap.setOnMapLongClickListener(this);
        mMap.setOnMarkerClickListener(this);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());


                Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

                try {

                    List<Address> listAddresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);

                    if (listAddresses != null && listAddresses.size() > 0) {


                        String address = "";

                        if (listAddresses.get(0).getSubThoroughfare() != null) {

                            address += listAddresses.get(0).getSubThoroughfare() + " ";

                        }

                        if (listAddresses.get(0).getThoroughfare() != null) {

                            address += listAddresses.get(0).getThoroughfare() + ", ";

                        }

                        if (listAddresses.get(0).getLocality() != null) {

                            address += listAddresses.get(0).getLocality() + ", ";

                        }

                        if (listAddresses.get(0).getPostalCode() != null) {

                            address += listAddresses.get(0).getPostalCode() + ", ";

                        }

                        if (listAddresses.get(0).getCountryName() != null) {

                            address += listAddresses.get(0).getCountryName();

                        }

                    }

                } catch (IOException e) {

                    e.printStackTrace();

                }

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };

        if (Build.VERSION.SDK_INT < 23) {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);

        } else {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

            } else {

                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);

                Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                userLocation = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                mMap.clear();

                marker=mMap.addMarker(new MarkerOptions().position(userLocation).title("Vasa lokacija").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(userLocation));
                mMap.animateCamera(CameraUpdateFactory.zoomTo(15.0f));
            }


        }
        mojabaza.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

               if(!HomeActivity.prijava) {
                   try {
                       Teren teren1 = dataSnapshot.getValue(Teren.class);
                       LatLng latLng = new LatLng(teren1.getLat(), teren1.getLng());
                       marker = mMap.addMarker(new MarkerOptions().position(latLng).title(teren1.getIme()));
                   } catch (NullPointerException e) {
                       e.printStackTrace();
                   }
               }
               else
               {
                   try
                   {
                       Teren teren1 = dataSnapshot.getValue(Teren.class);
                       if(Math.abs(userLocation.latitude-teren1.getLat())<=0.01 && Math.abs(userLocation.longitude-teren1.getLng())<=0.01)
                       {
                           LatLng latLng = new LatLng(teren1.getLat(), teren1.getLng());
                           marker = mMap.addMarker(new MarkerOptions().position(latLng).title(teren1.getIme()));
                       }

                   }
                   catch (NullPointerException e)
                   {
                       e.printStackTrace();
                   }
               }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }

    @Override
    public void onMapLongClick(LatLng latLng) {

        if(DodajterenActivity.moze){
            Teren t = new Teren(DodajterenActivity.editText.getText().toString(), DodajterenActivity.arrayList, latLng.latitude, latLng.longitude);
            String id=mojabaza.push().getKey();
            mojabaza.child(id).setValue(t);
            mMap.addMarker(new MarkerOptions().position(latLng).title(DodajterenActivity.editText.getText().toString()));
            DodajterenActivity.moze=false;
        }
        else
        {
            Toast.makeText(this,"Prvo morate uneti ime terena i sportove koji se igraju na njemu",Toast.LENGTH_LONG).show();
            startActivity(new Intent(MapsActivity.this,DodajterenActivity.class));
        }
    }

    @Override
    public boolean onMarkerClick(final Marker marker) {

        if(marker.getTitle().equals("Vasa lokacija"))
        {
            Toast.makeText(this, "Vasa lokacija ne predstavlja teren. Morate kliknuti na lokaciju nekog terena da bi videli njegovo trenutno stanje",Toast.LENGTH_LONG).show();
        }
        else
            if(!HomeActivity.prijava)
        {
            startActivity(new Intent(MapsActivity.this,InfoterActivity.class));
            prenos=marker.getTitle();
        }
        else
            {

                mojabaza2.addChildEventListener(new ChildEventListener() {
                   @Override
                   public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                       k=dataSnapshot.getValue(Korisnik.class);
                       if(k.getMail().equals(user.getEmail())) {
                           if (k.getNaterenu().equals("nije")) {
                               imek=k.getUsername();
                               new AlertDialog.Builder(MapsActivity.this)
                                       .setIcon(R.drawable.terenislika)
                                       .setTitle("Prijava!")
                                       .setMessage("Da li zelite da se prijavite na teren"+marker.getTitle()+"?")
                                       .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                                           @Override
                                           public void onClick(DialogInterface dialog, int which) {
                                               int sati = Calendar.getInstance().getTime().getHours();
                                               int minuti=Calendar.getInstance().getTime().getMinutes();
                                               String tekst = marker.getTitle();
                                               String id = mojabaza3.push().getKey();
                                               mojabaza3.child(id).setValue(new Objava(tekst, imek,"Kosarka",HomeActivity.n,sati,minuti,"Korisnik se prijavio na teren!"));
                                               HomeActivity.n--;
                                               mojabaza2.child(user.getUid()).child("naterenu").setValue("jeste");
                                               mojabaza2.child(user.getUid()).child("teren").setValue(marker.getTitle());
                                               mojabaza2.child(user.getUid()).child("sport").setValue("Kosarka");
                                               Toast.makeText(MapsActivity.this, "Uspesno ste se prijavili", Toast.LENGTH_SHORT).show();
                                               startActivity(new Intent(MapsActivity.this, HomeActivity.class));
                                           }
                                       })
                               .setNegativeButton("NE", new DialogInterface.OnClickListener() {
                                   @Override
                                   public void onClick(DialogInterface dialog, int which) {

                                   }
                               }).show();
                           }
                           else
                           {

                               s123=k.getUsername();
                               t=k.getTeren();
                               new AlertDialog.Builder(MapsActivity.this)
                                      .setIcon(R.drawable.terenislika)
                                      .setTitle("Odjava!")
                                      .setMessage("Da bi se prijavili na neki teren morate da se odjavite sa onog na kom ste trenutno.Da li zelite da se odjavite sa terena?")
                                      .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                                          @Override
                                          public void onClick(DialogInterface dialog, int which) {
                                              int sati = Calendar.getInstance().getTime().getHours();
                                              int minuti=Calendar.getInstance().getTime().getMinutes();
                                              String kor = s123;
                                              String id = mojabaza3.push().getKey();
                                              mojabaza3.child(id).setValue(new Objava(t, kor,"Kosarka",HomeActivity.n,sati,minuti,"Korisnik se odjavio sa terena!"));
                                              HomeActivity.n--;
                                              mojabaza2.child(user.getUid()).child("naterenu").setValue("nije");
                                              mojabaza2.child(user.getUid()).child("teren").setValue("");
                                              mojabaza2.child(user.getUid()).child("sport").setValue("");
                                              Toast.makeText(MapsActivity.this, "Uspesno ste se odjavili", Toast.LENGTH_SHORT).show();
                                              startActivity(new Intent(MapsActivity.this, HomeActivity.class));
                                          }
                                      })
                                      .setNegativeButton("NE", new DialogInterface.OnClickListener() {
                                          @Override
                                          public void onClick(DialogInterface dialog, int which) {

                                          }
                                      }).show();
                           }
                       }
                   }

                   @Override
                   public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                   }

                   @Override
                   public void onChildRemoved(DataSnapshot dataSnapshot) {

                   }

                   @Override
                   public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                   }

                   @Override
                   public void onCancelled(DatabaseError databaseError) {

                   }
               });
            }

        return false;
    }
}