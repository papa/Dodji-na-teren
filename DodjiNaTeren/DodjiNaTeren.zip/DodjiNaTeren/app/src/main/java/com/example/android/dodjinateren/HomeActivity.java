package com.example.android.dodjinateren;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ThrowOnExtraProperties;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener{

    private FirebaseAuth firebaseAuth;
    DatabaseReference mojabaza;
     FirebaseUser user;
     ArrayList<Objava> arrayList;
     ListView listView;
     ObjavaAdapter adapter;
     DatabaseReference mojabaza2;
     FirebaseDatabase baza;
     DatabaseReference mojabaza3;
     static Integer n;
     static boolean prijava;

     @Override
    protected void onStart() {
        super.onStart();
        DodajterenActivity.moze=false;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        DodajterenActivity.moze=false;
        prijava=false;
        n = -1;
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        firebaseAuth = FirebaseAuth.getInstance();

        //if the user is not logged in
        //that means current user will return null
        if(firebaseAuth.getCurrentUser() == null){
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
        user = firebaseAuth.getCurrentUser();

        baza=FirebaseDatabase.getInstance();
        mojabaza=baza.getReference().child(user.getUid());
        mojabaza2=baza.getReference("Objave");
        mojabaza3=baza.getReference("Korisnici");

        listView=(ListView)findViewById(R.id.listaobjava);
        arrayList=new ArrayList<Objava>();
        adapter=new ObjavaAdapter(this,arrayList);
        listView.setAdapter(adapter);

        mojabaza2.orderByChild("red").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Objava o=dataSnapshot.getValue(Objava.class);
                arrayList.add(o);
                n--;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.tereni) {
           Intent intent=new Intent(HomeActivity.this,TereniActivity.class);
           startActivity(intent);
        } else if (id == R.id.prijatelji) {
         Intent intent=new Intent(HomeActivity.this,KorisniciActivity.class);
         startActivity(intent);
        } else if (id == R.id.mapa) {
         Intent intent=new Intent(this,MapsActivity.class);
         startActivity(intent);
         prijava=false;
        }
        else if(id==R.id.pozovi)
        {
            Intent i=new Intent(HomeActivity.this,Main3Activity.class);
            startActivity(i);
        }
        else if(id==R.id.sportovi)
        {
            Intent intent=new Intent(this,SportoviActivity.class);
            startActivity(intent);
        }
        else if(id==R.id.logout)
        {
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(this,LoginActivity.class));
        }
        else if(id==R.id.check)
        {
             startActivity(new Intent(this,MapsActivity.class));
            prijava=true;
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void Otvori(View view)//uradi na drugi nacin za username
    {
        AlertDialog.Builder dialog=new AlertDialog.Builder(this);
        LayoutInflater inflater=getLayoutInflater();
        final View dialogview=inflater.inflate(R.layout.update_dialog,null);
        dialog.setView(dialogview);
        dialog.setTitle("Zelite da promenite username?");
        AlertDialog alertDialog=dialog.create();
    }
}
