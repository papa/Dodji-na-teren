package com.example.android.dodjinateren;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by jane on 12/26/2017.
 */
public class ObjavaAdapter extends ArrayAdapter<Objava> {

    public ObjavaAdapter (Activity context, ArrayList<Objava> objave)
    {
        super(context,0,objave);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view=convertView;
        if(view==null)
        {
            view= LayoutInflater.from(getContext()).inflate(R.layout.objava_item,parent,false);
        }
        Objava objava=getItem(position);
        TextView spt=(TextView) view.findViewById(R.id.ouser);
        spt.setText(objava.getKorisnik());
        TextView d=(TextView)view.findViewById(R.id.ovreme);
        d.setText(objava.getSat()+":"+objava.getMinut());
        TextView ter=(TextView)view.findViewById(R.id.oteren);
        ter.setText(objava.getTeren());
        TextView sport=(TextView)view.findViewById(R.id.osport);
        sport.setText(objava.getSport());
        TextView st=(TextView)view.findViewById(R.id.ostatus);
        st.setText(objava.getStatus());
        ImageView i=(ImageView)view.findViewById(R.id.slikao);
        i.setImageResource(R.drawable.terenislika);
        return view;
    }
}
