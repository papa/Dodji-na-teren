package com.example.android.dodjinateren;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class InfoterActivity extends AppCompatActivity {

    ArrayList<String> arrayList=new ArrayList<>();
    ArrayList<String> arrayList2;
    ArrayAdapter<String> adapter;
    ArrayAdapter<String> adapter2;
    ListView listView;
    ListView listView2;
    DatabaseReference mojabaza;
    TextView textView;
    int br;
    ImageView imageView;
    TextView textView2;
    TextView textView3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        br=0;
        imageView=(ImageView)findViewById(R.id.slikanema);
        textView2=(TextView)findViewById(R.id.tekstnema);
        imageView.setVisibility(View.INVISIBLE);
        textView2.setVisibility(View.INVISIBLE);
        textView3=(TextView)findViewById(R.id.koris);
        arrayList2=new ArrayList<>();
       //listView=(ListView)findViewById(R.id.listas);
        listView2=(ListView)findViewById(R.id.listak);
       /* adapter=new ArrayAdapter<String>(InfoterActivity.this,android.R.layout.simple_list_item_1,arrayList); */
        adapter2=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList2);
        listView2.setAdapter(adapter2);

        textView=(TextView)findViewById(R.id.imete);
        textView.setText(MapsActivity.prenos);
        //listView.setAdapter(adapter);
        mojabaza= FirebaseDatabase.getInstance().getReference("Korisnici");

        ChildEventListener childEventListener = mojabaza.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Korisnik k = dataSnapshot.getValue(Korisnik.class);
                if (k.getTeren().equals(MapsActivity.prenos)) {
                    br=br+1;
                    arrayList2.add(k.getUsername());
                    adapter2.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        if(br==0)
        {
            imageView.setVisibility(View.VISIBLE);
            textView2.setVisibility(View.VISIBLE);
            textView3.setVisibility(View.INVISIBLE);
        }
        else
        {
            imageView.setVisibility(View.INVISIBLE);
            textView2.setVisibility(View.INVISIBLE);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        if(id==android.R.id.home)
        {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
