package com.example.android.dodjinateren;

import java.util.ArrayList;

/**
 * Created by jane on 12/5/2017.
 */

public class Teren {
    private String ime;
    private ArrayList<String> s;
    private double lat;
    private double lng;
    Teren()
    {

    }
    Teren(String i,ArrayList<String> s,double lat,double lng)
    {
        this.ime=i;
        this.s=s;
        this.lat=lat;
        this.lng=lng;
    }
    public String getIme()
    {
        return ime;
    }
    public ArrayList<String> gets()
    {
        return s;
    }
    public double getLat()
    {
        return lat;
    }
    public double getLng(){
        return lng;
    }
}
