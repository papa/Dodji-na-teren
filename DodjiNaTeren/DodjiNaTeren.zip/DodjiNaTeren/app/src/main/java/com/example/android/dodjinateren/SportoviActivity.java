package com.example.android.dodjinateren;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class SportoviActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        ArrayList<Sport> sportovi=new ArrayList<Sport>();
        sportovi.add(new Sport("Kosarka"));
        sportovi.add(new Sport("Fudbal"));
        sportovi.add(new Sport("Tenis"));
        sportovi.add(new Sport("Plivanje"));
        SportAdapter sportAdapter=new SportAdapter(this,sportovi);
        ListView listView=(ListView)findViewById(R.id.list);
        listView.setAdapter(sportAdapter);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        if(id==android.R.id.home)
        {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
